//Animations for 2D Castle Page
var tlSun = new TimelineMax();
var tlGhost = new TimelineMax();
var tlSky = new TimelineMax();
var tlFlag = new TimelineMax();
var tlStars = new TimelineMax({repeat:-1});

pauseBtn = document.getElementById("pause"),

tlSun
    .set(".body", {backgroundColor:"#bcf1fd"})
	.set("#Window_Ghost", {scale:0, opacity:0})
	.to("#Sun", 5,{
	  rotation: 360,
	  repeat:-1,
	  transformOrigin:"center center",
	  ease:Power0.easeNone,
	});

tlStars
	.to(".Star", 0.5,{scale:1.25,opacity:1,transformOrigin:"center center"})
	.to(".Star", 0.5,{scale:1,opacity:0.5,transformOrigin:"center center"})
	.to(".Star", 0.5,{scale:0.75,opacity:0.25,transformOrigin:"center center"})
	.to(".Star", 0.5,{scale:1.25,opacity:1,transformOrigin:"center center"})
	.to(".Star", 0.5,{scale:1,opacity:0.25,transformOrigin:"center center"})
	.to(".Star", 0.5,{scale:0.75,opacity:0.75,transformOrigin:"center center"});


$("#Window_Up_R").click(function() {
    tlGhost
    	.set("#Window_Ghost", {scale:0, opacity:0, y:40})
        .to("#WindowText",1, {opacity:0})
    	.to("#Window_Ghost",1.5,{
			scale:1,
			opacity: 1,
			transformOrigin:"bottom left",
		}, '-=1')
		.to("#Window_Ghost",1,{
			opacity:0,
		},'+=1');	
 });

$("#Sun").click(function() {
    tlSky
    	.set("#Day", {scale:0, opacity:0})
    	.set(".body", {backgroundColor:"#110037"})
        .to("#SunText",1,{opacity:0});
 });

$("#Moon").click(function() {
    tlSky
    	.set("#Day", {scale:1, opacity:1})
    	.set(".body", {backgroundColor:"#bcf1fd"});
 });


$(".Peace_Flag").click(function() {
    tlFlag
        .to(".FlagText",1,{opacity:0})
    	.to(".Flag",0.5,{
    		rotationY:90,
    		transformOrigin:"center center",
    		transformPerspective:100
    	},'-=1')
    	.set(".Peace_Flag",{scale:0}, '-=0.5')
    	.to(".Flag",0.5,{
    		rotationY:180,
    		transformOrigin:"center center",
    		transformPerspective:100
    	},'-=0.5')
 });

$(".War_Flag").click(function() {
    tlFlag
    	.to(".Flag",0.5,{
    		rotationY:90,
    		transformOrigin:"center center",
    		transformPerspective:200
    	})
    	.set(".Peace_Flag",{scale:1})
    	.to(".Flag",0.5,{
    		rotationY:180,
    		transformOrigin:"center center",
    		transformPerspective:200
    	})
 });

$(".FlagL").click(function() {
    tlSun
        .to("#FlagLText",1,{opacity:0});
 });

//////////////////////////////////////////////////////////////////
//MENU

//Animated buttons

    //The opening animation
TweenMax.staggerFrom(".button", 0.6, {y:"-50", opacity:0,delay:0.5, ease: Elastic.easeOut}, 0.5);
    //This one is for the menu buttons on other pages.
TweenMax.staggerFrom(".menu", 0.6, {y:"-50", opacity:0,delay:0.1, ease: Elastic.easeOut}, 0.5);

    //The hover animations
$(".rules").on("mouseenter", function(){
  TweenMax.to(".rules", 0.2, {scale:1.2, rotation:-5,})
});

$(".rules").on("mouseleave", function(){
  TweenMax.to(".rules", 0.2, {scale:1, rotation:0,})
});

$(".3D").on("mouseenter", function(){
  TweenMax.to(".3D", 0.2, {scale:1.2, rotation:5,})
});

$(".3D").on("mouseleave", function(){
  TweenMax.to(".3D", 0.2, {scale:1, rotation:0})
});

$(".2D").on("mouseenter", function(){
  TweenMax.to(".2D", 0.2, {scale:1.2, rotation:5,})
});

$(".2D").on("mouseleave", function(){
  TweenMax.to(".2D", 0.2, {scale:1, rotation:0,})
});

//popup
TweenMax.set(".popup", {x:800})


$(".rules").click(function() {
TweenMax.set(".popup", {x:800})
    TweenMax.to(".popup", 1,{opacity:1, scale:1, x: -375})
 });

$(".popup").click(function() {
    TweenMax.to(".popup", 1,{x:800});
    
 });




