/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('bucket-up', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 2000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.
    targetEl.setAttribute('animation__position', {
      property: 'position',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '-8.5 1 -2'
    });

  }
});


/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('handle-up', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 2000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.
    targetEl.setAttribute('animation__position', {
      property: 'position',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '-8.5 0.8 -2'
    });

  }
});





/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('watermove-up', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 2000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.
    targetEl.setAttribute('animation__position', {
      property: 'position',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '-8.5 1.202 -2'
    });

  }
});





/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('waterstill-up', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 2000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.
    targetEl.setAttribute('animation__position', {
      property: 'position',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '-8.5 1.202 -2'
    });

  }
});





/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('rope-up', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 2000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.
    targetEl.setAttribute('animation__position', {
      property: 'position',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '-8.5 1.56 -2'
    });
    targetEl.setAttribute('animation__scale', {
      property: 'height',
      startEvents: 'set-image-fade',
      dir: 'alternate',
      dur: data.dur,
      
      to: '0.1'
    });

  }
});







/* global AFRAME */

/**
 * Component that listens to an event, fades out an entity, swaps the texture, and fades it
 * back in.
 */
AFRAME.registerComponent('door-closed', {
  schema: {
    on: {type: 'string'},
    target: {type: 'selector'},
    color: {type: 'string'},
    dur: {type: 'number', default: 4000}
  },

  init: function () {
    var data = this.data;
    var el = this.el;

    this.setupFadeAnimation();

    el.addEventListener(data.on, function () {
      // Fade out image.
      data.target.emit('set-image-fade');
      // Wait for fade to complete.
      setTimeout(function () {
        // Set image.
        //data.target.emit('set-image-move');
      }, data.dur);

    });
  },

  /**
   * Setup fade-in + fade-out.
   */
  setupFadeAnimation: function () {
    var data = this.data;
    var targetEl = this.data.target;
    // Only set up once.

    // Create animation.


    targetEl.setAttribute('animation__opacity', {
        property: 'opacity',
        startEvents: 'set-image-fade',
        dir: 'alternate',
        dur: data.dur,
        
        to: '1'
      });

  }
});